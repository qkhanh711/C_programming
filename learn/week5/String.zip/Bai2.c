#include <stdio.h>
#include <string.h>


int main(void){
    char A[100], B[100];
    scanf("%s", A);
    getchar();
    scanf("%s", B);
    int i = 0;
    while (A[i] != NULL && B[i] != NULL){
        if (A[i]  == B[i]){
            B[i] = '-';
        }
        i++;

    }
    printf("%s\n", B);
}